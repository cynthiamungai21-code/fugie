NOVA EXACT DASHBOARD — STATIC NETLIFY PACKAGE

This ZIP recreates the supplied mobile dashboard screenshot as a responsive static website:
- dark green/black interface
- top contract tabs
- Volatility 50 (1s) market selector and additional Volatility market choices
- green tick-chart visual
- digit frequency tiles
- Auto/Manual mode
- target profit, stop loss, loss multiplier
- stake controls and increment buttons
- AI Scanner preview button
- Even/Odd trade panels

IMPORTANT:
This is a visual front-end replica. The chart and digit percentages are illustrative values matching the screenshot, not live market data. It does not connect to a Deriv account, use OAuth, or place trades.

NETLIFY:
1. Extract this ZIP.
2. Upload the extracted folder (containing index.html) as a manual deploy to a separate Netlify site, or use it as a visual reference to merge into your existing Next.js GitHub project.
3. Do not overwrite your existing fugie Next.js deployment with this static package if you need to preserve its existing Deriv login and trade features.
