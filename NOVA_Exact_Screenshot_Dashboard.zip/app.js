const canvas=document.getElementById('chart'),ctx=canvas.getContext('2d');
function draw(){const dpr=window.devicePixelRatio||1,w=canvas.clientWidth,h=canvas.clientHeight;canvas.width=w*dpr;canvas.height=h*dpr;ctx.scale(dpr,dpr);ctx.clearRect(0,0,w,h);
  for(let i=1;i<=4;i++){let y=h*i/5;ctx.beginPath();ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.strokeStyle='#234536';ctx.lineWidth=1;ctx.stroke()}
  const pts=[.54,.68,.59,.72,.70,.61,.45,.37,.33,.51,.58,.82,.74,.86,.77,.94,.83,.99,.64,.35,.26,.47,.59,.67,.56,.78,.86,.64,.68];
  const points=pts.map((v,i)=>[4+i*(w-8)/(pts.length-1),h-(v*(h-15))-3]);
  ctx.beginPath();points.forEach((p,i)=>i?ctx.lineTo(...p):ctx.moveTo(...p));ctx.strokeStyle='#4bd7a2';ctx.lineWidth=3;ctx.lineJoin='round';ctx.lineCap='round';ctx.shadowColor='#32d99a';ctx.shadowBlur=5;ctx.stroke();ctx.shadowBlur=0;
  ctx.lineTo(points[points.length-1][0],h);ctx.lineTo(points[0][0],h);ctx.closePath();const g=ctx.createLinearGradient(0,0,0,h);g.addColorStop(0,'rgba(54,207,145,.23)');g.addColorStop(1,'rgba(54,207,145,0)');ctx.fillStyle=g;ctx.fill();
  const last=points[points.length-1];ctx.beginPath();ctx.arc(last[0],last[1],5,0,Math.PI*2);ctx.fillStyle='#5de4b0';ctx.fill();
}
window.addEventListener('resize',draw);draw();
let stake=15;const value=document.getElementById('stakeValue');function setStake(n){stake=Math.max(.35,Math.round(n*100)/100);value.textContent=Number.isInteger(stake)?stake:stake.toFixed(2)}
document.getElementById('minus').onclick=()=>setStake(stake-1);document.getElementById('plus').onclick=()=>setStake(stake+1);
document.querySelectorAll('[data-add]').forEach(b=>b.onclick=()=>setStake(stake+Number(b.dataset.add)));
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tab').forEach(x=>x.classList.remove('active'));b.classList.add('active');const mode=b.dataset.tab;document.querySelectorAll('.trade-buttons strong').forEach((x,i)=>{x.textContent=mode==='evenodd'?['Even','Odd'][i]:mode==='matches'?['Matches','Differs'][i]:['Over','Under'][i]})});
document.querySelectorAll('.mode').forEach(b=>b.onclick=()=>{document.querySelectorAll('.mode').forEach(x=>x.classList.remove('active'));b.classList.add('active');document.getElementById('notice').textContent=b.dataset.mode==='auto'?'Auto analysis selected — connect an authorized Deriv account for live signals.':'Manual mode selected — choose your contract and stake.'});
document.getElementById('scanner').onclick=()=>{document.getElementById('notice').textContent='AI Scanner preview: connect live Deriv tick data to calculate real digit statistics.'};
document.querySelectorAll('[data-trade]').forEach(b=>b.onclick=()=>{document.getElementById('notice').textContent=b.dataset.trade+' selected. Trade execution is not connected in this visual replica.'});
