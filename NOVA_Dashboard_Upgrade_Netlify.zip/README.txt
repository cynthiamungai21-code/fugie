NOVA AI Deriv Dashboard — Netlify ZIP

WHAT THIS ZIP DOES
- Provides a mobile-first dark green/black dashboard inspired by the supplied reference.
- Connects to Deriv's public market-data WebSocket using app_id 1089.
- Requests available Volatility markets and subscribes to the selected market's ticks.
- Calculates digit frequency from ticks received in this browser session.
- Includes visual Auto/Manual controls, scan refresh, risk fields and stake controls.

IMPORTANT LIMITATIONS
- This is a standalone front-end replacement, not a patch to your existing source code.
- It does NOT include your existing Deriv OAuth login, private account connection, proposal/buy flow, or trade history.
- Trade buttons intentionally do not execute trades.
- The confidence display is a simple descriptive statistic, not a calibrated probability of winning.
- Public tick availability and the sample app ID may be subject to Deriv API requirements. If the stream does not connect, replace APP_ID in app.js with your registered Deriv application ID.
- Do not enter API tokens into this static app.

NETLIFY DEPLOY
1. Download and unzip this archive.
2. In Netlify, open the EXISTING site's Deploys page.
3. Drag the extracted folder (the folder containing index.html) into the manual deploy drop zone, or upload the extracted folder using the deploy UI.
4. This replaces the files served by that site. Save a copy of your current deployed files first.
5. Test the site and confirm the LIVE status and changing quote.

To preserve the existing OAuth and real-account trading connection, the original site source ZIP or GitHub repository is needed so the upgrade can be merged into that code rather than replacing it with this standalone front end.
