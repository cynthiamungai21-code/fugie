# NOVA FX dashboard — Netlify ZIP

This package recreates the supplied dark green/black NOVA dashboard layout as a responsive static web app.

## Deploy to Netlify
1. Extract this ZIP.
2. In Netlify, choose **Add new site → Deploy manually**.
3. Drag the extracted `nova-dashboard-netlify` folder (the folder containing `index.html`) into the deploy area.

## Included
- Matches/Differs, Even/Odd and Over/Under contract tabs (UI selection).
- Five 1-second Volatility market selectors.
- Public Deriv WebSocket tick feed with reconnect.
- Live price, last digit, chart and digit frequency.
- Auto/Manual mode selector, risk fields and stake controls.
- Responsive mobile-first green/black layout.

## Important connection and trading limitation
The app ID provided by the user is used for the public market-data WebSocket connection. This does **not** log into a Deriv account. Trade buttons are intentionally disabled until a verified OAuth callback and secure authenticated trading flow are configured. Do not place API tokens or client secrets in browser JavaScript. This ZIP is a dashboard UI + public tick-feed starter, not a fully authenticated trading bot.
